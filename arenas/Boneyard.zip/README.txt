Optional
========

Apply ArenaRainbows.dll like any other mod. It is used for the permanent moon effect.