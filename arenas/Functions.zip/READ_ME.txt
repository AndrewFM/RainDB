Made by Ubaser

Devi#0468 on discord

-- Instructions --

1. Copy and paste everything within the Functions folder into D:\Games\Steam\steamapps\common\Rain World\Levels on your computer,
2. Start the game and it should work.

PS. If you didn't download RW through Steam, then open the Rain World\Levels folder wherever you downloaded the game.

-----------------

If for some reason the arena does not pop up in-game, please consult a modder on what you might be doing wrong,

Thank you.